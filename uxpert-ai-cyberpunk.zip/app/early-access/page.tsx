"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { CursorEffect } from "@/components/cursor-effect"
import { ParticleBackground } from "@/components/particle-background"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Zap, Star, Users, Rocket } from "lucide-react"

export default function EarlyAccessPage() {
  const [email, setEmail] = useState("")
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      <CursorEffect />
      <ParticleBackground />
      <div className="relative z-10">
        <Navigation />

        <main className="container mx-auto px-4 py-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto text-center"
          >
            <div className="mb-16">
              <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                Get Early Access
              </h1>
              <p className="text-xl text-gray-300 max-w-2xl mx-auto">
                Join the exclusive beta program and be among the first to experience the future of UX feedback
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6 mb-12">
              {[
                {
                  icon: Zap,
                  title: "Lightning Fast",
                  description: "Get feedback in under 10 seconds",
                },
                {
                  icon: Star,
                  title: "Premium Features",
                  description: "Access to all pro features for free",
                },
                {
                  icon: Users,
                  title: "Exclusive Community",
                  description: "Connect with top designers worldwide",
                },
              ].map((benefit, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="glass-card p-6 rounded-xl border border-cyan-500/30 backdrop-blur-xl bg-black/40"
                >
                  <benefit.icon className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
                  <p className="text-gray-300">{benefit.description}</p>
                </motion.div>
              ))}
            </div>

            {!submitted ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="glass-card p-8 rounded-2xl border border-purple-500/30 backdrop-blur-xl bg-black/40 max-w-md mx-auto"
              >
                <Rocket className="w-16 h-16 text-purple-400 mx-auto mb-6" />
                <h2 className="text-2xl font-bold mb-4">Join the Beta</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <Input
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="bg-black/50 border-gray-600 text-white placeholder-gray-400"
                    required
                  />
                  <Button type="submit" className="cyber-button w-full">
                    Get Early Access
                  </Button>
                </form>
                <p className="text-xs text-gray-400 mt-4">Limited spots available. No spam, ever.</p>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="glass-card p-8 rounded-2xl border border-green-500/30 backdrop-blur-xl bg-black/40 max-w-md mx-auto"
              >
                <div className="text-6xl mb-4">🎉</div>
                <h2 className="text-2xl font-bold mb-4 text-green-400">You're In!</h2>
                <p className="text-gray-300">Welcome to the future of UX feedback. We'll send you an invite soon!</p>
              </motion.div>
            )}
          </motion.div>
        </main>

        <Footer />
      </div>
    </div>
  )
}
