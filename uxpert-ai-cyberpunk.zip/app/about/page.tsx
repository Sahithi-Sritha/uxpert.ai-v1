"use client"

import { motion } from "framer-motion"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { CursorEffect } from "@/components/cursor-effect"
import { ParticleBackground } from "@/components/particle-background"
import { Brain, Zap, Target, Cpu } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      <CursorEffect />
      <ParticleBackground />
      <div className="relative z-10">
        <Navigation />

        <main className="container mx-auto px-4 py-20">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                About Our AI
              </h1>
              <p className="text-xl text-gray-300 max-w-2xl mx-auto">
                Powered by advanced machine learning algorithms trained on millions of design patterns and UX principles
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-16">
              {[
                {
                  icon: Brain,
                  title: "Neural Design Analysis",
                  description:
                    "Our AI processes visual elements, layout patterns, and user flow to provide comprehensive feedback on your designs.",
                },
                {
                  icon: Zap,
                  title: "Instant Feedback",
                  description:
                    "Get real-time analysis in seconds, not hours. Our optimized models deliver lightning-fast insights.",
                },
                {
                  icon: Target,
                  title: "Precision Scoring",
                  description:
                    "Detailed scoring across multiple UX dimensions including accessibility, usability, and visual hierarchy.",
                },
                {
                  icon: Cpu,
                  title: "Continuous Learning",
                  description:
                    "Our AI constantly evolves, learning from the latest design trends and user behavior patterns.",
                },
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="glass-card p-6 rounded-xl border border-cyan-500/30 backdrop-blur-xl bg-black/40 hover:border-cyan-400/50 transition-colors duration-300"
                >
                  <feature.icon className="w-12 h-12 text-cyan-400 mb-4" />
                  <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                  <p className="text-gray-300">{feature.description}</p>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="glass-card p-8 rounded-2xl border border-purple-500/30 backdrop-blur-xl bg-black/40 text-center"
            >
              <h2 className="text-3xl font-bold mb-4 text-purple-400">The Future of UX Feedback</h2>
              <p className="text-gray-300 text-lg leading-relaxed">
                Traditional UX reviews take weeks and cost thousands. Our AI delivers expert-level feedback instantly,
                democratizing access to world-class design insights. Join the revolution in design optimization.
              </p>
            </motion.div>
          </motion.div>
        </main>

        <Footer />
      </div>
    </div>
  )
}
