"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { CursorEffect } from "@/components/cursor-effect"
import { ParticleBackground } from "@/components/particle-background"
import { Upload, FileImage, Link, Download, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function UploadPage() {
  const [isUploading, setIsUploading] = useState(false)
  const [uploadComplete, setUploadComplete] = useState(false)
  const [progress, setProgress] = useState(0)

  const handleUpload = () => {
    setIsUploading(true)
    setProgress(0)

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsUploading(false)
          setUploadComplete(true)
          return 100
        }
        return prev + 2
      })
    }, 50)
  }

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      <CursorEffect />
      <ParticleBackground />
      <div className="relative z-10">
        <Navigation />

        <main className="container mx-auto px-4 py-20">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                Upload Your Design
              </h1>
              <p className="text-xl text-gray-300">Get instant AI-powered UX feedback in seconds</p>
            </div>

            {!uploadComplete ? (
              <motion.div
                className="glass-card p-8 rounded-2xl border border-cyan-500/30 backdrop-blur-xl bg-black/40"
                whileHover={{ scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="border-2 border-dashed border-cyan-500/50 rounded-xl p-12 text-center hover:border-cyan-400 transition-colors duration-300">
                  <Upload className="w-16 h-16 mx-auto mb-4 text-cyan-400" />
                  <h3 className="text-2xl font-semibold mb-2">Drop your files here</h3>
                  <p className="text-gray-400 mb-6">PNG, JPEG, or Figma link</p>

                  <div className="flex gap-4 justify-center mb-6">
                    <Button className="cyber-button" onClick={handleUpload} disabled={isUploading}>
                      <FileImage className="w-4 h-4 mr-2" />
                      Choose File
                    </Button>
                    <Button variant="outline" className="cyber-button-outline">
                      <Link className="w-4 h-4 mr-2" />
                      Figma Link
                    </Button>
                  </div>

                  {isUploading && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full">
                      <div className="w-full bg-gray-800 rounded-full h-3 mb-4 overflow-hidden">
                        <motion.div
                          className="h-full bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full"
                          style={{ width: `${progress}%` }}
                          transition={{ duration: 0.1 }}
                        />
                      </div>
                      <p className="text-cyan-400">Analyzing your design... {progress}%</p>
                    </motion.div>
                  )}
                </div>
              </motion.div>
            ) : (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                <div className="glass-card p-6 rounded-xl border border-green-500/30 backdrop-blur-xl bg-black/40">
                  <div className="flex items-center gap-3 mb-4">
                    <Sparkles className="w-6 h-6 text-green-400" />
                    <h3 className="text-xl font-semibold text-green-400">Analysis Complete!</h3>
                  </div>

                  <div className="grid gap-4">
                    {[
                      {
                        title: "Visual Hierarchy",
                        score: 92,
                        feedback:
                          "Excellent use of typography and spacing. Consider increasing contrast for better accessibility.",
                      },
                      {
                        title: "User Flow",
                        score: 88,
                        feedback: "Clear navigation path. Add breadcrumbs for complex user journeys.",
                      },
                      {
                        title: "Accessibility",
                        score: 76,
                        feedback: "Good color contrast. Improve alt text and keyboard navigation support.",
                      },
                      {
                        title: "Mobile Responsiveness",
                        score: 94,
                        feedback: "Outstanding mobile optimization. Minor adjustments needed for tablet view.",
                      },
                    ].map((item, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="p-4 rounded-lg bg-gray-900/50 border border-gray-700"
                      >
                        <div className="flex justify-between items-center mb-2">
                          <h4 className="font-semibold">{item.title}</h4>
                          <span
                            className={`text-sm font-bold ${item.score >= 90 ? "text-green-400" : item.score >= 80 ? "text-yellow-400" : "text-orange-400"}`}
                          >
                            {item.score}/100
                          </span>
                        </div>
                        <p className="text-gray-300 text-sm">{item.feedback}</p>
                      </motion.div>
                    ))}
                  </div>

                  <Button className="cyber-button w-full mt-6">
                    <Download className="w-4 h-4 mr-2" />
                    Export PDF Report
                  </Button>
                </div>
              </motion.div>
            )}
          </motion.div>
        </main>

        <Footer />
      </div>
    </div>
  )
}
