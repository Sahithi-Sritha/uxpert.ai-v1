"use client"

import { motion } from "framer-motion"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { CursorEffect } from "@/components/cursor-effect"
import { ParticleBackground } from "@/components/particle-background"
import { CheckCircle, Circle, Clock } from "lucide-react"

export default function RoadmapPage() {
  const roadmapItems = [
    {
      quarter: "Q1 2024",
      status: "completed",
      items: [
        "AI-powered UX analysis engine",
        "Basic feedback scoring system",
        "PNG/JPEG upload support",
        "PDF report generation",
      ],
    },
    {
      quarter: "Q2 2024",
      status: "in-progress",
      items: [
        "Figma integration",
        "Advanced accessibility scoring",
        "Mobile responsiveness analysis",
        "Team collaboration features",
      ],
    },
    {
      quarter: "Q3 2024",
      status: "planned",
      items: [
        "Real-time design feedback",
        "A/B testing recommendations",
        "Custom brand guidelines",
        "API for developers",
      ],
    },
    {
      quarter: "Q4 2024",
      status: "planned",
      items: [
        "Video prototype analysis",
        "User behavior prediction",
        "Design system optimization",
        "Enterprise features",
      ],
    },
  ]

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-6 h-6 text-green-400" />
      case "in-progress":
        return <Clock className="w-6 h-6 text-yellow-400" />
      default:
        return <Circle className="w-6 h-6 text-gray-400" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "border-green-500/30"
      case "in-progress":
        return "border-yellow-500/30"
      default:
        return "border-gray-500/30"
    }
  }

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      <CursorEffect />
      <ParticleBackground />
      <div className="relative z-10">
        <Navigation />

        <main className="container mx-auto px-4 py-20">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                Roadmap
              </h1>
              <p className="text-xl text-gray-300">The future of AI-powered UX feedback is here</p>
            </div>

            <div className="space-y-8">
              {roadmapItems.map((quarter, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`glass-card p-6 rounded-xl border ${getStatusColor(quarter.status)} backdrop-blur-xl bg-black/40`}
                >
                  <div className="flex items-center gap-3 mb-4">
                    {getStatusIcon(quarter.status)}
                    <h3 className="text-2xl font-bold">{quarter.quarter}</h3>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        quarter.status === "completed"
                          ? "bg-green-500/20 text-green-400"
                          : quarter.status === "in-progress"
                            ? "bg-yellow-500/20 text-yellow-400"
                            : "bg-gray-500/20 text-gray-400"
                      }`}
                    >
                      {quarter.status.replace("-", " ").toUpperCase()}
                    </span>
                  </div>

                  <div className="grid md:grid-cols-2 gap-3">
                    {quarter.items.map((item, itemIndex) => (
                      <div key={itemIndex} className="flex items-center gap-2">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            quarter.status === "completed"
                              ? "bg-green-400"
                              : quarter.status === "in-progress"
                                ? "bg-yellow-400"
                                : "bg-gray-400"
                          }`}
                        />
                        <span className="text-gray-300">{item}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </main>

        <Footer />
      </div>
    </div>
  )
}
