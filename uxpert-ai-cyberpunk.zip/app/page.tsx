"use client"
import { Navigation } from "@/components/navigation"
import { Hero } from "@/components/hero"
import { HowItWorks } from "@/components/how-it-works"
import { Features } from "@/components/features"
import { Footer } from "@/components/footer"
import { CursorEffect } from "@/components/cursor-effect"
import { ParticleBackground } from "@/components/particle-background"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      <CursorEffect />
      <ParticleBackground />
      <div className="relative z-10">
        <Navigation />
        <Hero />
        <HowItWorks />
        <Features />
        <Footer />
      </div>
    </div>
  )
}
